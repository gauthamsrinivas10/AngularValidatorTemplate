import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'employee-notfoundpage',
  templateUrl: './notfoundpage.component.html',
  styleUrls: ['./notfoundpage.component.css']
})
export class NotfoundpageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
