import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import IProduct from 'src/app/interface/product';
import { HttpClient } from '@angular/common/http';
@Component({
  selector: 'employee-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})
export class ProductDetailsComponent implements OnInit {

  product: IProduct | null = null;
  constructor(private route : ActivatedRoute, private http : HttpClient, private router : Router) { 
    this.route.params.subscribe((params : any)=>{
      this.http.get<IProduct>(`http://localhost:4500/products/${params.id}`).subscribe((data)=>{
        this.product = data;
      })
    })
  }

  ngOnInit(): void {
  }
  navigateToProducts(){
    this.router.navigate(["/product"])
    //this.router.navigate(["/products" , "/1" , "/discount"])
   
  }
}
