import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule , ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from "@angular/common/http"
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { HighlightDirective } from './directives/highlight.directive';
import { ColorDirective } from './directives/color.directive';
import { HomeComponent } from './pages/home/home.component';
import { ProductComponent } from './pages/product/product.component';
import { ContactComponent } from './pages/contact/contact.component';
import { HeaderComponent } from './components/header/header.component';
import { NotfoundpageComponent } from './pages/notfoundpage/notfoundpage.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { SignuptemplateComponent } from './forms/signuptemplate/signuptemplate.component';
import { RegisterformComponent } from './forms/registerform/registerform.component';
import { ValidateEqualModule } from 'ng-validate-equal';

@NgModule({
  declarations: [
    AppComponent,
    
    HighlightDirective,
    ColorDirective,
    HomeComponent,
    ProductComponent,
    ContactComponent,
    HeaderComponent,
    NotfoundpageComponent,
    ProductDetailsComponent,
    SignuptemplateComponent,
    RegisterformComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,   
    ValidateEqualModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
