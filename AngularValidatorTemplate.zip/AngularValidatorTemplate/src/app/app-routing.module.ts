import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ContactComponent } from './pages/contact/contact.component';
import { HomeComponent } from './pages/home/home.component';
import { NotfoundpageComponent } from './pages/notfoundpage/notfoundpage.component';
import { ProductDetailsComponent } from './pages/product-details/product-details.component';
import { ProductComponent } from './pages/product/product.component';

const routes: Routes = [
  {
    path : "" , component : HomeComponent
  },
  {
    path : "product" , component : ProductComponent
  },
  {
    path: "product/:id" , component : ProductDetailsComponent 
  },
  {
    path : "contact" , component : ContactComponent
  },
  {
    path : "**" , component: NotfoundpageComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
